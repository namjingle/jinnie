.. Downloader Cog Reference

Downloader Cog Reference
========================

.. automodule:: redbot.cogs.downloader

.. autoclass:: redbot.cogs.downloader.downloader.Downloader
    :members:
