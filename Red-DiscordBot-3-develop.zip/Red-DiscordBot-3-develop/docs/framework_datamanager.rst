.. data manager docs

============
Data Manager
============

Data manager is a module that handles all the information necessary to bootstrap
the bot into a state where more abstract data management systems can take over.

.. automodule:: redbot.core.data_manager
    :members:
